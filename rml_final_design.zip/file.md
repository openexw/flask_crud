# app


+ models 模型
+ templates 视图、模板
+ web 控制器
+ validates 验证（控制 -> 验证）
+ static 资源文件夹

# config
> 配置文件

+ app.py 项目配置文件
+ databases.py 数据库配置文件

# main.py 入口文件
 