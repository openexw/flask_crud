"""
Created by ranml on 2019/1/28
"""
__author__ = 'ranml'

DEBUG = True
SECRET_KEY = '12435646546546dfgdgfdgfdszd'
