"""
Created by ranml on 2019/1/28
"""
__author__ = 'ranml'

SQLALCHEMY_DATABASE_URI = "mysql+cymysql://homestead:secret@192.168.10.10:3306/rml_final_design"
# SQLALCHEMY_DATABASE_URI = "mysql+cymysql://rml_final_design:BZaab8BFXsM4F8Ck@127.0.0.1:3306/rml_final_design"
# SQLALCHEMY_DATABASE_URI = "mysql+cymysql://root:123456@127.0.0.1:3306/crud"